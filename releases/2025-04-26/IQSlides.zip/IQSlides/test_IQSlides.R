testLogFile <- "/IQDESKTOP/.validation/testlog_IQSlides.txt"
sink(file=testLogFile)
testthat::test_dir("/tmp/05_validation/IQSlides/testthat")
sink()
