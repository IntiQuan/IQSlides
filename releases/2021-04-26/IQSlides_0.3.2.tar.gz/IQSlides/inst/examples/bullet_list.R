bl <- IQ_bullet_list(
  "* Bullet point with **bold** and *italic*" ,
  "* Another bullet point",
  "  * Indented by two spaces",
  "  * Another one",
  "* And back to ***really* outer** level",
  "* Some sort of formula `E~rel~ = m\\*c^2^`"
)

